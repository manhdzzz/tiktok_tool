"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AvgColor = void 0;
var AvgColor;
(function (AvgColor) {
    AvgColor["Ebebff"] = "#EBEBFF";
    AvgColor["Empty"] = "";
})(AvgColor = exports.AvgColor || (exports.AvgColor = {}));
//# sourceMappingURL=WebCastTikTokApiInterface.js.map