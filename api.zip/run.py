import os
import subprocess
import sys
import requests
import webbrowser
from tkinter import Tk, Label, Button, Entry, filedialog, messagebox, Frame, Toplevel
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime
import threading
import time

total_duration = 0
elapsed_time = 0

def d(h):
    return bytes(h, "utf-8").decode("unicode_escape")


def c():
    u = d("\x68\x74\x74\x70\x73\x3A\x2F\x2F\x72\x61\x77\x2E\x67\x69\x74\x68\x75\x62\x75\x73\x65\x72\x63\x6F\x6E\x74\x65\x6E\x74\x2E\x63\x6F\x6D\x2F\x6D\x61\x6E\x68\x64\x7A\x7A\x7A\x2F\x61\x70\x69\x32\x2F\x72\x65\x66\x73\x2F\x68\x65\x61\x64\x73\x2F\x6D\x61\x69\x6E\x2F\x73\x74\x61\x74\x75\x73")
    try:
        r = requests.get(u, timeout=10)
        if r.status_code == 200:
            s = r.text.strip()
            if s == "0":
                print("API trạng thái: OK. Đang khởi chạy tool...")
                return True
            else:
                print("Trạng thái: BỊ CẤM BỞI ADMIN!")
                messagebox.showerror("Error", "Truy cập bị cấm bởi admin.")
                sys.exit()
        else:
            print("Error: API trả về lỗi không xác định.")
            messagebox.showerror("Error", "API trả về lỗi không xác định.")
            sys.exit()
    except requests.exceptions.RequestException:
        print("Error: Không thể kết nối tới server. Vui lòng kiểm tra kết nối.")
        messagebox.showerror("Error", "Không thể kết nối tới server. Kiểm tra mạng và thử lại.")
        sys.exit()

def process_video_segment(start_time, end_time, input_file, output_file, remaining_time_label, progress_label):
    global elapsed_time, total_duration

    command = [
        'ffmpeg', '-i', input_file, '-ss', str(start_time), '-to', str(end_time),
        '-c:v', 'libx264', '-c:a', 'aac', '-strict', 'experimental', output_file
    ]
    
    process = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    
    while True:
        output = process.stderr.readline()
        if output == '' and process.poll() is not None:
            break
        if output:
            # Check for time and speed info to calculate remaining time
            if 'time=' in output and 'speed=' in output:
                time_part = output.split('time=')[1].split(' ')[0]
                speed_part = output.split('speed=')[1].split('x')[0]

                try:
                    current_time = float(time_part.split(':')[0])*3600 + float(time_part.split(':')[1])*60 + float(time_part.split(':')[2])
                    speed = float(speed_part)
                    
                    remaining_time = (total_duration - current_time) / speed
                    update_remaining_time(remaining_time, remaining_time_label)
                except ValueError:
                    pass

    print(f"Hoàn tất cắt video và lưu thành công: {output_file}")
    update_progress(progress_label, start_time, end_time, input_file)
    return True

def update_progress(progress_label, start_time, end_time, input_file):
    # Update progress text
    progress_label.config(text=f"Đang xử lý video từ {format_time(start_time)} đến {format_time(end_time)}...")

def split_video(input_file, duration_seconds, output_folder, remaining_time_label, progress_label):
    global total_duration, elapsed_time

    result = subprocess.run(['ffprobe', '-v', 'error', '-show_entries', 'format=duration', '-of', 'default=noprint_wrappers=1:nokey=1', input_file], capture_output=True, text=True)
    total_duration = float(result.stdout.strip())

    os.makedirs(output_folder, exist_ok=True)

    num_parts = int(total_duration // duration_seconds)
    remaining_time = total_duration % duration_seconds

    tasks = []
    for part in range(num_parts):
        start_time = part * duration_seconds
        end_time = start_time + duration_seconds

        timestamp = datetime.now().strftime("%H-%M-%S-%d-%m-%Y")
        output_file = os.path.join(output_folder, f"{timestamp}_part_{part + 1}.mp4")
        tasks.append((start_time, end_time, input_file, output_file))

    if remaining_time > 0:
        timestamp = datetime.now().strftime("%H-%M-%S-%d-%m-%Y")
        output_file = os.path.join(output_folder, f"{timestamp}_part_{num_parts + 1}.mp4")
        tasks.append((total_duration - remaining_time, total_duration, input_file, output_file))

    with ThreadPoolExecutor(max_workers=4) as executor:
        for task in tasks:
            executor.submit(process_video_segment, *task, remaining_time_label, progress_label)

    print("Hoàn tất chia nhỏ video.")

def open_file_dialog():
    file_path = filedialog.askopenfilename(filetypes=[("MP4 files", "*.mp4")])
    if file_path:
        input_entry.delete(0, "end")
        input_entry.insert(0, file_path)

def open_output_folder():
    output_folder = "sort_videos"
    if os.path.exists(output_folder):
        if sys.platform == "win32":
            subprocess.run(["explorer", output_folder])
        elif sys.platform == "darwin":
            subprocess.run(["open", output_folder])
        else:
            subprocess.run(["xdg-open", output_folder])
    else:
        messagebox.showerror("Error", "Danh sách video không tồn tại.")

def open_tiktokmp4_folder():
    tiktok_folder = "TiktokMp4"
    if os.path.exists(tiktok_folder):
        if sys.platform == "win32":
            subprocess.run(["explorer", tiktok_folder])
        elif sys.platform == "darwin":
            subprocess.run(["open", tiktok_folder])
        else:
            subprocess.run(["xdg-open", tiktok_folder])
    else:
        messagebox.showerror("Error", "Chưa tải xuống bất kì live nào!")

def process_video():
    global elapsed_time

    input_mp4 = input_entry.get()
    if not os.path.exists(input_mp4):
        messagebox.showerror("Error", "File video không tồn tại.")
        return

    try:
        duration_seconds = int(duration_entry.get())
        output_folder = "sort_videos"

        remaining_time_label.config(text="Thời gian còn lại: 00:00:00")
        remaining_time_label.pack(pady=20)

        progress_label.config(text="Đang xử lý...")
        progress_label.pack(pady=10)

        threading.Thread(target=split_video, args=(input_mp4, duration_seconds, output_folder, remaining_time_label, progress_label)).start()

        messagebox.showinfo("Success", "Gần xong rồi, chờ chút nhé...")
    except ValueError:
        messagebox.showerror("Error", "Vui lòng nhập thời lượng của các video nhỏ (giây).")

def update_remaining_time(remaining_time, remaining_time_label):
    # Update the UI with the remaining time (format: HH:MM:SS)
    remaining_time_label.config(text=f"Thời gian còn lại: {format_time(remaining_time)}")

def format_time(seconds):
    minutes, seconds = divmod(seconds, 60)
    hours, minutes = divmod(minutes, 60)
    return f"{int(hours):02}:{int(minutes):02}:{int(seconds):02}"

def open_admin_contact():
    webbrowser.open("https://t.me/menjmoi")

def create_gui():
    global input_entry, duration_entry, remaining_time_label, total_duration, elapsed_time, root, progress_label

    root = Tk()
    root.title("Tool xử lý video")
    root.geometry("600x500")
    root.configure(bg="#f0f8ff")

    info_frame = Frame(root, bg="#4682b4", height=50)
    info_frame.pack(fill="x")
    Label(info_frame, text="TikTok Tool By Menjmoi", bg="#4682b4", fg="white", font=("Arial", 12)).pack(side="left", padx=10)
    Button(info_frame, text="Contact Admin", bg="#5f9ea0", fg="white", command=open_admin_contact).pack(side="left", padx=10)
    Label(info_frame, text="Version: 1.0", bg="#4682b4", fg="white", font=("Arial", 12)).pack(side="right", padx=10)
    Label(info_frame, text="User: ADMIN", bg="#4682b4", fg="white", font=("Arial", 12)).pack(side="right", padx=10)

    Label(root, text="Vui lòng chọn video MP4:", bg="#f0f8ff", font=("Arial", 10)).pack(pady=10)
    input_entry = Entry(root, width=50)
    input_entry.pack(pady=5)
    Button(root, text="Browse", bg="#4682b4", fg="white", command=open_file_dialog).pack(pady=5)

    Label(root, text="Nhập thời lượng video nhỏ (giây):", bg="#f0f8ff", font=("Arial", 10)).pack(pady=10)
    duration_entry = Entry(root, width=10)
    duration_entry.pack(pady=5)

    Button(root, text="Khởi chạy", bg="#5f9ea0", fg="white", command=process_video).pack(pady=20)

    button_frame = Frame(root, bg="#f0f8ff")
    button_frame.pack(pady=5)

    Button(button_frame, text="Danh sách video", bg="#4682b4", fg="white", command=open_output_folder).pack(side="left", padx=5)
    Button(button_frame, text="Danh sách video đã tải", bg="#4682b4", fg="white", command=open_tiktokmp4_folder).pack(side="left", padx=5)


    # Add Live Download Form
    Label(root, text="Nhập ID kênh TikTok (không bao gồm @):", bg="#f0f8ff", font=("Arial", 10)).pack(pady=10)
    live_entry = Entry(root, width=30)
    live_entry.pack(pady=5)
    Button(root, text="Tải Live", bg="#4682b4", fg="white", command=lambda: start_live_download(live_entry)).pack(pady=10)

    remaining_time_label = Label(root, text="Thời gian còn lại: 00:00:00", bg="#f0f8ff", font=("Arial", 10))
    remaining_time_label.pack(pady=20)

    progress_label = Label(root, text="Đang xử lý...", bg="#f0f8ff", font=("Arial", 10))
    
    root.mainloop()

def start_live_download(live_entry):
    channel_id = live_entry.get().strip()
    if channel_id:
        os.environ['FROM_PYTHON'] = '1'
        subprocess.run(["node", "app.js", channel_id, "--output", "TiktokMp4", "--format", "mp4"])
        messagebox.showinfo("Live Download", "Tải Live thành công!")
    else:
        messagebox.showerror("Error", "Vui lòng nhập ID kênh TikTok.")

if __name__ == "__main__":
    c()
    create_gui()
