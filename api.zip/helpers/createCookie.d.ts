import TiktokCookie from '../types/TikTokCookieInterface';
declare function createCookie(): Promise<TiktokCookie[]>;
export default createCookie;
