export interface OptionsProgram {
    output: string;
    format: string;
    debug: boolean;
}
