declare function evaluateCookie(): Promise<string>;
export default evaluateCookie;
