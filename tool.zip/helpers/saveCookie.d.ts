declare function saveCookie(): Promise<void>;
export default saveCookie;
