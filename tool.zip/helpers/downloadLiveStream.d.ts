export declare function downloadLiveStream(username: string, output: string, format: string): Promise<void>;
