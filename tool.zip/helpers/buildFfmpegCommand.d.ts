export default function buildFfmpegCommand(url: string, title: string, username: string, fileName: string, format: string, isFlv: boolean): string;
