import TiktokCookie from '../types/TikTokCookieInterface';
export declare function loadCookie(): TiktokCookie[];
export declare function cookieToString(cookies: TiktokCookie[]): string;
